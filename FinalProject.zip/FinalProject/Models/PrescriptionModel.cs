﻿using BE;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Linq;
using System.Web;

namespace FinalProject.Models
{


    public class PrescriptionModel
    {
        [DisplayName("Id")]
        public int Id { set; get; }
        [DisplayName("Medicine")]
        public int medicine { set; get; }
        [DisplayName("Start Date")]
        public DateTime StartDate { get; set; }
        [DisplayName("End Date")]
        public DateTime EndDate { get; set; }
        [DisplayName("Doctor")]
        public int Doctor { set; get; }
        [DisplayName("Patient")]
        public int Patient { set; get; }
        public string Cause { get; set; }

        public List<Prescription> Prescriptions { get; set; }
        //public PrescriptionModel() => this.Prescriptions = new List<Prescription>
        public PrescriptionModel()
        {
            Prescriptions = new List<Prescription>
        {
                new Prescription
                {
                 Id=1,
                 medicine = 02,
                StartDate=new DateTime(2020,10,4),
                EndDate = new DateTime(2020,10,10),
                Doctor=999,
                Patient=777,
                Cause="barzel less",
                },
                new Prescription
                {
                Id=2,
                medicine = 03,
                StartDate=new DateTime(2005,12,12),
                EndDate = new DateTime(2006,1,4),
                Doctor=999,
                Patient=777,
                Cause="B12 less",
                }

        };
        }

        public List<Prescription> GetPrescriptions()
        {
            return this.Prescriptions;
        }
        public Prescription GetPrescription(int id)
        {
            var result = (from f in Prescriptions
                          where f.Id == id
                          select f).Single<Prescription>();
            return result;
        }

        public int medIDToMame(string name)
        {
            BL.MedicineBL db =new BL.MedicineBL();
            var l = db.GetMedicines();
            var x = (from i in l
                     where i.Name == name
                     select i.Id).First();
            return x;
        }


    } }