﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.Entity;
using System.Linq;
using System.Net;
using System.Web;
using System.Web.Mvc;
using BE;
using BL;
namespace FinalProject.Controllers
{
    public class MedicinesController : Controller
    {
        // private Models.MedicineModel db = new Models.MedicineModel();
        private BL.MedicineBL db = new BL.MedicineBL();
        // GET: Medicines
        public ActionResult Index()
        {

            return View(db.GetMedicines());
        }

        // GET: Medicines/Details/5
        public ActionResult Details(int? id)
        {
            if (id == null)
            {
                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            }
            Medicine medicine = db.FindMedicine(id.GetValueOrDefault());
            if (medicine == null)
            {
                return HttpNotFound();
            }
            return View(medicine);
        }


        public ActionResult DetailsForDoctor(int? id)
        {
            if (id == null)
            {
                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            }
            Medicine medicine = db.FindMedicine(id.GetValueOrDefault());
            if (medicine == null)
            {
                return HttpNotFound();
            }
            return View(medicine);
        }



        // GET: Medicines/Create
        public ActionResult Create()
        {
            return View();
        }

        // POST: Medicines/Create
        // To protect from overposting attacks, enable the specific properties you want to bind to, for 
        // more details see https://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Create([Bind(Include = "Id,Name,Producer,GenericName,ActiveIngredients,PortionProperties,ImageUrl,NDC")] Medicine medicine, HttpPostedFileBase file)
        {
            if (ModelState.IsValid)
            {
                medicine.ImageUrl = file.FileName;
                var ImgPath = file.InputStream;
                //var ImgPath = collection["ImagePath"].ToString();
                var path = Server.MapPath(Url.Content($"~/images/{medicine.ImageUrl}"));
                ImageTagsLogic bl = new ImageTagsLogic();
                List<string> tags = bl.GetTags(path);
                if (tags.Count != 0)
                {
                    UploadFile(file);
                    db.AddMedicine(medicine);
                    return RedirectToAction("Index");
                }
                else
                {
                    Response.Write("<script>alert('Choose A Different Image ');</script>");
                }
            }

            return View(medicine);
        }
        [HttpPost]
        public void UploadFile(HttpPostedFileBase file)
        {
            GoogleDriveBl.UplaodFileOnDrive(file);
        }
        // GET: Medicines/Edit/5
        public ActionResult Edit(int? id)
        {
            if (id == null)
            {
                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            }
            Medicine medicine = db.FindMedicine(id.GetValueOrDefault());
            if (medicine == null)
            {
                return HttpNotFound();
            }
            return View(medicine);
        }

        // POST: Medicines/Edit/5
        // To protect from overposting attacks, enable the specific properties you want to bind to, for 
        // more details see https://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Edit([Bind(Include = "Id,Name,Producer,GenericName,ActiveIngredients,PortionProperties,ImageUrl,NDC")] Medicine medicine)
        {
            if (ModelState.IsValid)
            {
                db.UpdateMedicine(medicine);
                return RedirectToAction("Index");
            }
            return View(medicine);
        }

        // GET: Medicines/Delete/5
        public ActionResult Delete(int? id)
        {
            if (id == null)
            {
                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            }
            Medicine medicine = db.FindMedicine(id.GetValueOrDefault());
            if (medicine == null)
            {
                return HttpNotFound();
            }
            return View(medicine);
        }

        // POST: Medicines/Delete/5
        [HttpPost, ActionName("Delete")]
        [ValidateAntiForgeryToken]
        public ActionResult DeleteConfirmed(int id)
        {
            Medicine medicine = db.FindMedicine(id);
            db.DeletMedicine(medicine);
            return RedirectToAction("Index");
        }
public ActionResult MedicinesCatalog()
        {
            return View(db.GetMedicines().ToList());
        }

        protected override void Dispose(bool disposing)
        {
            if (disposing)
            {
                db.Dispose();
            }
        }

    }
}




