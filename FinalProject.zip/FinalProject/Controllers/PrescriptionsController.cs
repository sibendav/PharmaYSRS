﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.Entity;
using System.Linq;
using System.Net;
using System.Web;
using System.Web.Mvc;
using BE;
using FinalProject.Models;
using BL;
namespace FinalProject.Controllers
{
    public class PrescriptionsController : Controller
    {
        
        private BL.PrescriptionBL db = new BL.PrescriptionBL();

        // GET: Prescriptions
        public ActionResult Index( int id)
        {
            return View(db.GetPrescriptionByPatientsId(id));
        }

        // GET: Prescriptions/Details/5
        public ActionResult Details(int? id)
        {
            if (id == null)
            {
                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            }
            Prescription prescription = db.FindPrescription(id.GetValueOrDefault());

            if (prescription == null)
            {
                return HttpNotFound();
            }
            return View(prescription);
        }

        // GET: Prescriptions/Create
        public ActionResult Create()
        {        
            return View();
        }

        // POST: Prescriptions/Create
        // To protect from overposting attacks, enable the specific properties you want to bind to, for 
        // more details see https://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
      //  [ValidateAntiForgeryToken]
        public ActionResult Create([Bind(Include = "Id,medicine,StartDate,EndDate,Doctor,Patient,Cause")] Prescription prescription)
        {
            BL.MedicineBL mbd = new BL.MedicineBL();
            if (ModelState.IsValid)
            {
                List<string> colliListResult = new List<string>();
                List<string> ruxiList1 = new List<string>();
                List<string> listNdc1 = db.GetNDCList(prescription.Patient);
                listNdc1.Add(mbd.FindMedicine(prescription.medicine).NDC);
                //List<string> listNdc1 = new List<string>() { "0006-3916", "0006-4094", "0006-4826", "0002-0800", "0002-3115", "0002-3231" };

                BL.ConvertingAndCollisionTestBL Cact = new BL.ConvertingAndCollisionTestBL();
                ruxiList1 = Cact.ConveresionToRXCUI(listNdc1);
                colliListResult = Cact.CollisionTest(ruxiList1);
                if (colliListResult==null || colliListResult.Count == 0)//אין התנגשות
                {
                    db.AddPrescription(prescription);
                    Response.Write("<script>alert('The Precription Added Succesfully!');</script>");
                    return RedirectToAction("MedicinesCatalog" ,"Medicines");
                }
                else//יש התנגשות
                {
                    Response.Write("<script>alert('There Is A Medicines Collision');</script>");

                }
            }

            return View(prescription);

        }

        // GET: Prescriptions/Edit/5

        protected override void Dispose(bool disposing)
        {
            if (disposing)
            {
                db.Dispose();
            }
            base.Dispose(disposing);
        }
    }
}
