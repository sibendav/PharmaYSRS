﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Web;
using System.Web.Mvc;
using BE;
using BL;
using FinalProject.Models;
namespace FinalProject.Controllers
{
    public class HomeController : Controller
    {
        // GET: Home
        public ActionResult Index()
        {
            return View();
        }
        public ActionResult DocPage()
        {
            return View();
        }


        public ActionResult Contact([Bind(Include = "Name,StartDate,EndtDate")] ChartModel cm)
        {
            //var cm = new ChartModel();
            return View(cm);
        }

        public ActionResult Charts(ChartModel cm )
        {
            BL.MedicineBL bl = new BL.MedicineBL();
            var count = bl.AmountOfMedByDate(cm.Name, cm.StartDate, cm.EndDate);
            List<int> toArray = new List<int>();
            List<int> values = toArray;
            values.Add((int)count);
            return View(values);
        }








        public ActionResult Signin()
        {
            return View();
        }

        [HttpPost]
        public ActionResult SignIn(string mailD, string passD)
        {
            if (mailD == null)
            {
                //להוסיף פה שגיאת הכנסת נתונים
                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            }
            if ((mailD == "maneger@gmail.com" )&& (passD=="1234"))
            {
                return RedirectToAction("Index","Medicines");
            }



            DoctorBL db = new DoctorBL();

            Doctor doctor = db.getDoctorByEmail(mailD);




            if((doctor!=null ) && (passD ==doctor.Password))
            { 
                        return RedirectToAction("Docpage");
            }
            else
            {
                Response.Write("<script>alert('Wrong Password Or Email Adress- Try Again! ');</script>");
                return RedirectToAction("SignIn", "Home");

            }



        }




    }
}