﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using BE;
using System.Data.Entity;

namespace DAL
{
     public class AdministratorDAL
    {
        public void Dispose()
        {
            AdministratorContext db = new AdministratorContext();
            db.Dispose();
        }

        #region Administrator
        public void AddAdministrator(Administrator d)
        {
            using (var ctx = new AdministratorContext())
            {
                ctx.Administrators.Add(d);
                ctx.SaveChanges();
            }
        }
        public void UpdateAdministrator(Administrator d)
        {

            AdministratorContext db = new AdministratorContext();
            db.Entry(d).State = EntityState.Modified;
            db.SaveChanges();
        }
        public IEnumerable<Administrator> GetAdministrator()
        {
            AdministratorContext db = new AdministratorContext();
            return db.Administrators;
        }
        public Administrator FindAdministrator(int id)
        {

            using (var ctx = new AdministratorContext())
                return ctx.Administrators.Find(id);
        }

        public void DeletAdministrator(Administrator d)
        {
            AdministratorContext db = new AdministratorContext();
            db.Entry(d).State = EntityState.Deleted;
            db.SaveChanges();
        }
        #endregion Administrator
    }
}
