﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using BE;
using System.Data.Entity;
using System.Security.Cryptography;

namespace DAL
{
    public class PrescriptionDAL
    {

        public void Dispose()
        {
            PrescriptionsContext db = new PrescriptionsContext();
            db.Dispose();
        }
        public void AddPrescription(Prescription d)
        {
            using (var ctx = new PrescriptionsContext())
            {
                ctx.Prescriptions.Add(d);
                ctx.SaveChanges();
            }
        }
        public IEnumerable<Prescription> GetPrescription()
        {
            PrescriptionsContext db = new PrescriptionsContext();
            return db.Prescriptions;
        }
        public Prescription FindPrescription(int id)
        {

            using (var ctx = new PrescriptionsContext())
                return ctx.Prescriptions.Find(id);
        }
        public List<string> GetNDCList(int d)
        {

             DAL.MedicineDAL db = new DAL.MedicineDAL();
            var x = GetPrescription().ToList();
            var a = from i in x
                    where i.Patient == d
                    select db.FindMedicine(i.medicine).NDC;
           return a.ToList();
                 
        }


    }
}