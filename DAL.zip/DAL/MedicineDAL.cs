﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using BE;
using System.Data.Entity;
using TestGoogleDriveMVC;

namespace DAL
{
    public class MedicineDAL
    {

        public void Dispose()
        {
            MedicinesContext db = new MedicinesContext();
            db.Dispose();
        }


        public void AddMedicine(Medicine d)
        {
            using (var ctx = new MedicinesContext())
            {
                ctx.Medicines.Add(d);
                ctx.SaveChanges();
            }
        }
        public void UpdateMedicine(Medicine d)
        {
            using (var ctx = new MedicinesContext())
            {
                ctx.Entry(d).State = EntityState.Modified;
                ctx.SaveChanges();
            }
            
        }
        public IEnumerable<Medicine> GetMedicines()
        {
           
            MedicinesContext db = new MedicinesContext();
            return db.Medicines;
        }
        public Medicine FindMedicine(int id)
        {

            using (var ctx = new MedicinesContext())
                return ctx.Medicines.Find(id);
        }

        public void DeletMedicine(Medicine d)
        {
            GoogleDriveImage img = FindMedicineImg(d.ImageUrl);
            GoogleDriveMethods.DeleteImage(img);
            DAL.MedicinesContext db = new MedicinesContext();
            db.Entry(d).State = EntityState.Deleted;
            db.SaveChanges();
        }
        public GoogleDriveImage FindMedicineImg(string id)
        {
            return (from item in GoogleDriveMethods.GetDriveFiles()
                    where item.Name == id
                    select item).First();
        }

        public int AmountOfMedByDate(string m, DateTime StartDate, DateTime EndDate)
        {
            DAL.MedicineDAL db = new DAL.MedicineDAL();
            var ml = db.GetMedicines();
            try {
                int idd = (from item in ml
                           where item.Name == m
                           select item.Id).First();


                DAL.PrescriptionDAL pdb = new DAL.PrescriptionDAL();
                var pl = pdb.GetPrescription();

                int counter = (from item in pl
                               where (item.medicine == idd) && ((item.StartDate < EndDate) && (item.EndDate > StartDate))
                               select item).ToList().Count();

                return counter;

            }
            catch { }
            return 0;
        }



        }
    }

