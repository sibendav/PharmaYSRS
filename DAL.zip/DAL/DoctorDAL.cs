﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data.Entity;
using BE;
namespace DAL
{
    public class DoctorDAL
    {


        public void Dispose()
        {
            DoctorsContext db = new DoctorsContext();
            db.Dispose();
        }

        public void AddDoctor(Doctor d)
        {
            using (var ctx = new DoctorsContext())
            {
                ctx.Doctors.Add(d);
                ctx.SaveChanges();
            }
        }
        public void UpdateDoctor(Doctor d)
        {
            using (var ctx = new DoctorsContext())
            {
                ctx.Entry(d).State = EntityState.Modified;
                ctx.SaveChanges();
          }
        }
        public IEnumerable<Doctor> GetDoctors()
        {
           DoctorsContext db = new DoctorsContext();
            return db.Doctors;
        }
        public Doctor FindDoctor(int id)
        {
           using (var ctx = new DoctorsContext())
                return ctx.Doctors.Find(id);
        }

        public void DeletDoctor(Doctor d)
        {

            using (var ctx = new DoctorsContext())
            {
                ctx.Entry(d).State = EntityState.Deleted;
                ctx.SaveChanges();
            }
           
        }
    }
}
