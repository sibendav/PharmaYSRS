﻿using BE;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Text;
using System.Threading.Tasks;
using System.Xml;



namespace DAL
{
    public class ConvertingAndCollisionTestDAL
    {
        List<string> ruxiList = new List<string>();



        //List<string> listNdc1 = new List<string>() { "0006-3916", "0006-4094", "0006-4826" ,"27106","152923","104490"};


        public List<string> ConveresionToRXCUI(List<string> listNdc)
        {


            foreach (var item in listNdc)
            {
                var httpRequest = (HttpWebRequest)WebRequest.Create("  https://rxnav.nlm.nih.gov/REST/rxcui?idtype=NDC&id=" + item);
                var answer = (HttpWebResponse)httpRequest.GetResponse();
                var getStream = answer.GetResponseStream();
                var myS = new XmlDocument();
                myS.Load(getStream);
                getStream.Close();
                XmlNodeList elementList = myS.GetElementsByTagName("rxnormId");
                var innerText = elementList.Item(0).InnerText;
                ruxiList.Add(innerText);

            }
            return ruxiList;
        }
        public List<string> CollisionTest(List<string> ruxiList)
        {
            List<string> colliList = new List<string>();
            string Url = "https://rxnav.nlm.nih.gov/REST/interaction/list?rxcuis=";

            foreach (var item in ruxiList)
            {
                Url = (Url + item + "+");

            }
            Url = Url.Remove(Url.Length - 1);
            var httpRequest = (HttpWebRequest)WebRequest.Create(Url);
            var answer = (HttpWebResponse)httpRequest.GetResponse();
            var getString = answer.GetResponseStream();
            var myS = new XmlDocument();
            myS.Load(getString);
            getString.Close();
            XmlNodeList elementListSeverity = myS.GetElementsByTagName("severity");
            XmlNodeList elementListDescription = myS.GetElementsByTagName("description");
            if (elementListDescription.Count > 0)
            {

                foreach (var item in elementListSeverity)
                {
                    string serverity = elementListDescription.Item(0).InnerText;
                    string descreption = elementListDescription.Item(0).InnerText;
                    colliList.Add(serverity + descreption);

                }

            }
            else

            {
                return null;
            }

            return colliList;
        }
    }
}