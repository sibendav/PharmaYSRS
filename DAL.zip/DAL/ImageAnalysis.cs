﻿using Newtonsoft.Json;
using BE;
using RestSharp;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Microsoft.Graph;
using static DAL.Helper;

namespace DAL
{
    public class ImageAnalysis
    {
        public void GetTags(ImageDetails CurrentImage)
        {
            string apiKey = "acc_c4ce731bb14dcf7";
            string apiSecret = "8d833fd35787d0450fc558d13451d0f2";

            //string apiKey = "acc_b3c30b5c43feb5c";
            //string apiSecret = "2933eed8aaf9e8c60e559ee75f6373ad";

            string image = CurrentImage.ImagePath;

            string basicAuthValue = System.Convert.ToBase64String(System.Text.Encoding.UTF8.GetBytes(String.Format("{0}:{1}", apiKey, apiSecret)));

            var client = new RestClient("https://api.imagga.com/v2/tags");
            client.Timeout = -1;

            var request = new RestRequest(Method.POST);

            request.AddHeader("Authorization", String.Format("Basic {0}", basicAuthValue));

            request.AddFile("image", image);

            IRestResponse response = client.Execute(request);
            Rooti TagList = JsonConvert.DeserializeObject<Rooti>(response.Content);

            foreach (var item in TagList.result.tags)
            {
                CurrentImage.Details.Add(item.tag.en, item.confidence);
            }

        }

    }
}
