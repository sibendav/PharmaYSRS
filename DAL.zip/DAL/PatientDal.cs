﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using BE;
using System.Data.Entity;

namespace DAL
{
   public class PatientDal
    {

        public void Dispose()
        {
            PatientsContext db = new PatientsContext();
            db.Dispose();
        }

        public void AddPatient(Patient d)
        {
            using (var ctx = new PatientsContext())
            {
                ctx.Patients.Add(d);
                ctx.SaveChanges();
            }
        }
        public void UpdatePatient(Patient d)
        {

            PatientsContext db = new PatientsContext();
            db.Entry(d).State = EntityState.Modified;
            db.SaveChanges();
        }
        public IEnumerable<Patient> GetPatient()
        {

          
            PatientsContext db = new PatientsContext();
            return db.Patients;
        }
        public Patient FindPatient(int id)
        {

            using (var ctx = new PatientsContext())
                return ctx.Patients.Find(id);
        }

        public void DeletPatient(Patient d)
        {
           using (var ctx = new PatientsContext())
            {
                ctx.Entry(d).State = EntityState.Deleted;
                ctx.SaveChanges();
            }

        }

    }
}
