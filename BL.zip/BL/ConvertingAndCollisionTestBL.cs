﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Security.Cryptography;
using System.Text;
using System.Threading.Tasks;
using BE;
namespace BL
{
  public  class ConvertingAndCollisionTestBL
    {
        public List<string> ConveresionToRXCUI(List<string> listNdc)
        {
            DAL.ConvertingAndCollisionTestDAL db = new DAL.ConvertingAndCollisionTestDAL();
           return db.ConveresionToRXCUI(listNdc);
        }

        public List<string> CollisionTest(List<string> ruxiList)
  {
            DAL.ConvertingAndCollisionTestDAL db = new DAL.ConvertingAndCollisionTestDAL();
           return  db.CollisionTest(ruxiList);

        }
    }
}
