﻿using BE;
using DAL;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BL
{
    public class ImageTagsLogic
    {
        public List<string> GetTags(string path)
        {

            List<string> Result = new List<string>();

            ImageDetails DrugImage = new ImageDetails(path);

            ImageAnalysis dal = new ImageAnalysis();

            dal.GetTags(DrugImage);

            var Threshold = 10.0;

            const string V = "medicine";
            const string V1 = "pills";
            const string V2 = "pill";
            const string V3 = "pharmacy";
            const string V4 = "medical";
            const string V5 = "medication";
            const string V6 = "drugs";
            const string V7 = "drug";
            const string V8 = "health";
            const string V9 = "pill bottle";
            const string V10 = "prescription drug";
            const string V11 = "healty";



            foreach (var item in DrugImage.Details)
            {

                if (((item.Key == V) || (item.Key == V1) || (item.Key == V2) || (item.Key == V3) || (item.Key == V4) || (item.Key == V5) || (item.Key == V6) || (item.Key == V7) || (item.Key == V8) || (item.Key == V9) || (item.Key == V10) || (item.Key == V11)) && (item.Value > Threshold))
                {

                    Result.Add(item.Key);


                }


            }

            return Result;


        }

    }
}
