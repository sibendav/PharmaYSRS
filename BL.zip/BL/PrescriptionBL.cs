﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using BE;
namespace BL
{
   public class PrescriptionBL
    {

        public void Dispose()
        {
            DAL.PrescriptionDAL db = new DAL.PrescriptionDAL();
            db.Dispose();
        }

        public void AddPrescription(Prescription d)
        {
            //if (validation.IsEnglish(d.Cause) && validation.IsDate(d.StartDate.ToString()) && validation.IsDate(d.EndDate.ToString()))
            
                DAL.PrescriptionDAL db = new DAL.PrescriptionDAL();
                db.AddPrescription(d);
            
            //else
            {
                //Exception
            }
        }
        public IEnumerable<Prescription> GetPrescription()
        {
            DAL.PrescriptionDAL db = new DAL.PrescriptionDAL();
            return db.GetPrescription();
        }
        public IEnumerable<Prescription> GetPrescriptionByPatientsId(int id)
        {
            DAL.PrescriptionDAL db = new DAL.PrescriptionDAL();
            var l = db.GetPrescription();
            var x = (from i in l
                     where i.Patient == id
                     select i).ToList();
            return x;
        }
        public Prescription FindPrescription(int id)
        {

            DAL.PrescriptionDAL db = new DAL.PrescriptionDAL();
            return db.FindPrescription(id);

        }
        public List<string> GetNDCList(int d)
        {

            DAL.PrescriptionDAL db = new DAL.PrescriptionDAL();
            return db.GetNDCList(d);
        }


    }
}
