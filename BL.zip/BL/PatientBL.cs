﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using BE;
namespace BL
{
   public class PatientBL
    {
        public void Dispose()
        {
            DAL.PatientDal db = new DAL.PatientDal();
            db.Dispose();
        }
        #region Patient
        public void AddPatient(Patient d)
        {
            if (validation.IsEnglish(d.FirstName) && validation.IsEnglish(d.LastName) && validation.IsPhone(d.PhoneNumber) && validation.IsMailAddress(d.EmailAdress))
            {
                DAL.PatientDal db = new DAL.PatientDal();
                db.AddPatient(d);
            }
            else
            {
                //Exception
            }
        }
        public void UpdatePatient(Patient d)
        {
            if (validation.IsEnglish(d.FirstName) && validation.IsEnglish(d.LastName) && validation.IsPhone(d.PhoneNumber) && validation.IsMailAddress(d.EmailAdress))
            {
                DAL.PatientDal db = new DAL.PatientDal();
                db.UpdatePatient(d);
            }
            else
            {
                //Exception
            }
        }
        public IEnumerable<Patient> GetPatient()
        {

            DAL.PatientDal db = new DAL.PatientDal();
            return db.GetPatient();
        }
        public Patient FindPatient(int id)
        {

            DAL.PatientDal db = new DAL.PatientDal();
            return db.FindPatient(id);
        }

        public void DeletPatient(Patient d)
        {
            DAL.PatientDal db = new DAL.PatientDal();
            db.DeletPatient(d);
        }
        #endregion Patient
     


    }
}
