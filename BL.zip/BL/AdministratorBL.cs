﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using BE;
namespace BL
{
   public class AdministratorBL
    {

        public void Dispose()
        {
            DAL.AdministratorDAL db = new DAL.AdministratorDAL();
            db.Dispose();
        }

        #region Administrator
        public void AddAdministrator(Administrator d)
        {
            DAL.AdministratorDAL db = new DAL.AdministratorDAL();
            db.AddAdministrator(d);
        }
        public void UpdateAdministrator(Administrator d)
        {
            DAL.AdministratorDAL db = new DAL.AdministratorDAL();
            db.UpdateAdministrator(d);

        }
        public IEnumerable<Administrator> GetAdministrator()
        {
            DAL.AdministratorDAL db = new DAL.AdministratorDAL();
            return db.GetAdministrator();
        }
        public Administrator FindAdministrator(int id)
        {

            DAL.AdministratorDAL db = new DAL.AdministratorDAL();
            return db.FindAdministrator(id);
        }

        public void DeletAdministrator(Administrator d)
        {
            DAL.AdministratorDAL db = new DAL.AdministratorDAL();
            db.DeletAdministrator(d);
        }
        #endregion Administrator
    }
}
