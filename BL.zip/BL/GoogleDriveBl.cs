﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Web;
using TestGoogleDriveMVC;

namespace BL
{
    public class GoogleDriveBl
    {

        public static List<GoogleDriveImage> GetDriveFiles()
        {
            return DAL.GoogleDriveMethods.GetDriveFiles();
        }
        public static string DownloadImage(string id)
        {
            return DAL.GoogleDriveMethods.DownloadImage(id);
        }
        public static void DeleteImage(GoogleDriveImage file)
        {
            DAL.GoogleDriveMethods.DeleteImage(file);
        }
        public static void UplaodFileOnDrive(HttpPostedFileBase file)
        {
            DAL.GoogleDriveMethods.UplaodFileOnDrive(file);
        }
        
    }
}
