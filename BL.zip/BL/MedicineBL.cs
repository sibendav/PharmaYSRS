﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Security.Cryptography;
using System.Text;
using System.Threading.Tasks;
using BE;
namespace BL
{
   public class MedicineBL
    {
        public void Dispose()
        {
            DAL.MedicineDAL db = new DAL.MedicineDAL();
            db.Dispose();
        }

        #region Medicine
        public void AddMedicine(Medicine d)
        {
            if (validation.IsEnglish(d.Name) && validation.IsEnglish(d.Producer) && validation.IsEnglish(d.GenericName) && validation.IsEnglish(d.ActiveIngredients) && validation.IsEnglish(d.PortionProperties) && validation.IsEnglish(d.ImageUrl))
            {
                DAL.MedicineDAL db = new DAL.MedicineDAL();
                db.AddMedicine(d);
            }
            else
            {
                //Exception
            }
        }
        public void UpdateMedicine(Medicine d)
        {
            if (validation.IsEnglish(d.Name) && validation.IsEnglish(d.Producer) && validation.IsEnglish(d.GenericName) && validation.IsEnglish(d.ActiveIngredients) && validation.IsEnglish(d.PortionProperties) && validation.IsEnglish(d.ImageUrl))
            {
                DAL.MedicineDAL db = new DAL.MedicineDAL();
                db.UpdateMedicine(d);
            }
            else
            {
                //Exception
            }
        }
        public IEnumerable<Medicine> GetMedicines()
        {
            DAL.MedicineDAL db = new DAL.MedicineDAL();
            return db.GetMedicines();
        }
        public Medicine FindMedicine(int id)
        {

            DAL.MedicineDAL db = new DAL.MedicineDAL();
            return db.FindMedicine(id);
        }

        public void DeletMedicine(Medicine d)
        {
            DAL.MedicineDAL db = new DAL.MedicineDAL();
            db.DeletMedicine(d);
        }

        public int AmountOfMedByDate(string m, DateTime StartDate, DateTime EndDate)
        {
            if (m == null || StartDate == null || EndDate == null)
                return 0;
            DAL.MedicineDAL db = new DAL.MedicineDAL();
            return db.AmountOfMedByDate(m,StartDate,EndDate);

        }
















        #endregion Medicine
    }
}
