﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using BE;
namespace BL
{
    public class DoctorBL
    {
        public void Dispose()
        {
            DAL.DoctorDAL db = new DAL.DoctorDAL();
            db.Dispose();
        }
        #region Doctor
        public void AddDoctor(Doctor d)
        {
            if (validation.IsEnglish(d.FirstName) && validation.IsEnglish(d.LastName) && validation.IsPhone(d.PhoneNumber) && validation.IsMailAddress(d.EmailAdress))
            {
                DAL.DoctorDAL db = new DAL.DoctorDAL();
                db.AddDoctor(d);
            }
            else
            {
                //Exception
            }
        }
        public void UpdateDoctor(Doctor d)
        {
            if (validation.IsEnglish(d.FirstName) && validation.IsEnglish(d.LastName) && validation.IsPhone(d.PhoneNumber) && validation.IsMailAddress(d.EmailAdress))
            {
                DAL.DoctorDAL db = new DAL.DoctorDAL();
                db.UpdateDoctor(d);
            }
            else
            {
                //Exception
            }
        }
        public IEnumerable<Doctor> GetDoctors()
        {
            DAL.DoctorDAL db = new DAL.DoctorDAL();
            return db.GetDoctors();
        }
        public Doctor FindDoctor(int id)
        {
            DAL.DoctorDAL db = new DAL.DoctorDAL();
            return db.FindDoctor(id);
        }

        public void DeletDoctor(Doctor d)
        {
            DAL.DoctorDAL db = new DAL.DoctorDAL();
            db.DeletDoctor(d);
        }
        public Doctor getDoctorByEmail(string e)
        {
            DAL.DoctorDAL db = new DAL.DoctorDAL();
            var l = db.GetDoctors();
            Doctor d = null;
            try
            {
                 d = (from i in l
                     where i.EmailAdress == e
                     select i).First();
            }
            catch
            {}         
            if (d == null)
                return null;
            return d;
            //return d != null ? d : null;
        }

        #endregion Doctor
    }
}
