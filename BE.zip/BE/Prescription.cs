﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BE
{
    public class Prescription
    {
        public int Id { get; set; }
      //  [DisplayName("מספר תרופה")]
        public int medicine { get; set; }
      //  [DisplayName("תאריך התחלה")]

        public DateTime StartDate { get; set; }
       // [DisplayName("תאריך סיום")]

        public DateTime EndDate { get; set; }
      //  [DisplayName("נרשם על ידי הרופא")]

        public int Doctor { get; set; }
       // [DisplayName("תרופה עבור מטופל")]

        public int Patient { get; set; }
       // [DisplayName("סיבת נטילת התרופה")]

        public string Cause { get; set; }
        public override string ToString()
        {
            return $"Id:{Id} MedicineId:{medicine} StartDate:{StartDate} EndDate:{EndDate} DoctorId:{Doctor} PatientId:{Patient}";
        }

    }
}
