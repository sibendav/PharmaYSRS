﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BE
{
    public class Medicine
    {
        public int Id { get; set; }
      //  [DisplayName("שם התרופה")]
        public string Name { get; set; }

      //  [DisplayName("יצרן")]
        public string Producer { get; set; }
      //  [DisplayName("שם גנרי")]
        public string GenericName { get; set; }
       // [DisplayName("חומרים פעילים")]
        public string ActiveIngredients { get; set; }
       // [DisplayName("מאפיינים")]
        public string PortionProperties { get; set; }
      //  [DisplayName("תמונה")]
        public string ImageUrl { get; set; }

        //[DisplayName("NDC")]
        public string NDC { get; set; }

        public override string ToString()
        {
            return $"id:{Id} name:{Name}";
        }
    }
}
