﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BE
{
    public class Patient
    {

        public int Id { get; set; }
       // [DisplayName("שם פרטי")]

        public string FirstName { get; set; }
       // [DisplayName("שם משפחה")]

        public string LastName { get; set; }
      //  [DisplayName("מספר פלאפון")]

        public string PhoneNumber { get; set; }
      //  [DisplayName("כתובת מייל")]

        public string EmailAdress { get; set; }
       // [DisplayName("מרשמים")]

        public List<int> Prescriptions { get; set; }

        public override string ToString()
        {
            return $"Id:{Id} First Name:{FirstName} Last Name:{LastName} Phone Number:{PhoneNumber} Email Adress:{EmailAdress} Prescriptions:{Prescriptions}";
        }

    }
}
