﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BE
{
    public class Administrator
    {

        public int Id { get; set; }
        //[DisplayName("שם פרטי")]

        public string FirstName { get; set; }
        // [DisplayName("שם משפחה")]

        public string LastName { get; set; }
        // [DisplayName("שם סיסמה")]

        public string Password { get; set; }

        public string EmailAdress { get; set; }

       

    }
}
